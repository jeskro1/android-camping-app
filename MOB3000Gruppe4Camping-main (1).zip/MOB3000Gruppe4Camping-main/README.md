# MOB3000Gruppe4Camping

Rolf Salvesen, Jesper Krøgli, Sondre Matre

Dette er våres gruppe prosjekt til Applikasjons utvikling for mobile enheter.